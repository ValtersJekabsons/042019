<?php

$array[] = array('question' => 'Kurā gadā Romas Republika sabruka?',
'answers' => array('27. gads p.m.ē', '856. gads', '100. gads p.m.ē', '83. gads'),
'correct' => '27. gads p.m.ē');
$array[] = array('question' => 'Kāda bija Romas Republikas oficiālā valsts valoda?',
'answers' => array('Turku', 'Latīņu', 'Romiešu', 'Angļu'),
'correct' => 'Latīņu');




include '../ajax_things.php';

?>