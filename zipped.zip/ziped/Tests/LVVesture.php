<?php

$array[] = array('question' => 'Kurā gadā Latvija pievienojās Eiropas savienībai?',
'answers' => array('1992', '1991', '1990', '2004'),
'correct' => '2004');
$array[] = array('question' => 'Kurā gadā Latvijā pirmo reizi par maksāšanas līdzekli ieviesa latu?',
'answers' => array('1922', '1991', '1992', '1980'),
'correct' => '1922');




include '../ajax_things.php';

?>