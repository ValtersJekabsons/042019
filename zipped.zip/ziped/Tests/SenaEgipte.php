<?php

$array[] = array('question' => 'Kā dēvē cilvēkus, kas pēta seno Ēģipti?',
'answers' => array('Zinātnieki', 'Eģiptieši', 'Tādu nav', 'Eģiptologi'),
'correct' => 'Eģiptologi');
$array[] = array('question' => 'Cik dinastijas valdīja Senajā Ēģiptē?',
'answers' => array('7', '13', '18', '3'),
'correct' => '18');




include '../ajax_things.php';

?>