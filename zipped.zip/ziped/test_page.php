<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Tests</title>
	<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
	<body>
		<div class="container">
		<div class="progress-bar-container">
		  <div class="progress-bar" style="width:0%"></div>
		</div>

			<div id="content">
				<p id="question"></p>
				<div id="answer-box">
					<div class="answer-button" id="answer1" onclick="giveAnswer(this)">Button 1</div>
  					<div class="answer-button" id="answer2" onclick="giveAnswer(this)">Button 2</div>
  					<div class="answer-button" id="answer3" onclick="giveAnswer(this)">Button 3</div>
  					<div class="answer-button" id="answer4" onclick="giveAnswer(this)">Button 4</div>
				</div>

				<a id="start-button" href="index">
					<div class="answer-button">Uz sākumu</div>
				</a>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		var name = "<?php echo($_REQUEST['firstname']) ?>";
		var test = "<?php echo($_REQUEST['test']) ?>";
	</script>
	<script src="functions.js"></script>
	<script type="text/javascript">
		getNextQuestion(0);

	</script>
</html>