<?php

$question = $_REQUEST["question"];
$answer = $_REQUEST["answer"];

$message = "";
$question = intval($question);

if ($question === 0) {
  $message = count($array) . "|" . $array[0]['answers'][0]. "|" . $array[0]['answers'][1]. "|" . $array[0]['answers'][2]. "|" . $array[0]['answers'][3]. "|" . $array[0]['question'] ;
}
else{
  if ($answer === $array[$question-1]['correct']) {
    $aValue = 1;
    
  }else{
    $aValue = 0;
  }
  if ($question >= count($array)) {
    $message = $aValue;
  }else{
    $message = $aValue ."|". $array[$question]['answers'][0] ."|". $array[$question]['answers'][1] ."|". $array[$question]['answers'][2] ."|". $array[$question]['answers'][3] ."|". $array[$question]['question'];
  }
}


echo $message === "" ? "error" : $message;

?>