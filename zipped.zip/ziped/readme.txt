﻿1.) Kā darbojas lapas
2.) Kā darbojas informācijas apmaiņa
3.) Kā pievienot testu


1.)
Sākuma lapā ievada vārdu un izvēlas testu. Infomācija par testu un cilvēka vārdu
tiek nodota caur URL parametriem. Pēc tam saglabāti JS mainīgajos. Testa parametrs
tiek izmantots, lai iegūtu informācijas patekti no pareizā php faila.
Kad tests tiek pabeigts, variantu pogas tiek paslēptas un
šajā pašā lapā parādas testa rezūltāts, balvas attēls un balvas teksts.
Izpildot testu, iespējams iegūt 7 dažādas balvas. 3 variācijas pilnībā pareizi izpildītam testam.
3 variācijas daļēji pareizi izpildītam testam. 1 variācija pilnībā nepareizi izpildītam testam.



2.)
Informācija tik nodota ar ajax palīdzību. Klients serverim nodod pieprasījumu, kas
satur testa php faila nosaukumu, atbildi uz pagājušo jautājumu un tekošā jautājuma kārtas nr.
Pirmajā apmaiņā cipars 0 tiek nodots kā parametrs serverim, nesaturot atbildi.
php failā tas tiek atpazīts, kā pirmā datu apmaiņa.
Informācijas paketē tiek nosūtīts kopējais jautājumu daudzums, 1. jautājuma atbilžu varianti un 1. jautājums.

Kad klients izpilda jautājumu, tiek nosūtīs pieprasījums pēc nākošā jautājuma un 
aizsūtīta izvēlētā atbilde uz iepriekšējo jautājumu.

Atbilde tiek pārbaudīta un rezūltāts tiek ievieots informācijas paketē, līdz ar nākošā jautājuma
atbilžu variantiem un jautājumu.

Pēdējā sūtījumā klients izsūta paketi kā parasti, taču klients no
servera atbildes sagaida tikai izvēlētās atbildes rezūltātu. 


3.) Testu pievieno izveidojot mainīgo masīvu array ar jautājumu tekstu, jautājumu atbilžu variantus,
un pareizās atbildes. Visbeidzot includeojot php failu ar ajax kodu.