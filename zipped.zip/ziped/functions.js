
var nrOfQuestions = 0;//jautājumu skaits
var question = 0;//cik jautājumu ir izpildīti
var correct = 0;// cik jautājumi ir pareizi

/*
endPage noņem pogas no lapas un parāda sākuma pogu
*/
function endPage(){
	document.getElementById("answer-box").style.display = "none";
	document.getElementById("start-button").style.display = "block";
}

/*
setProgressBar apreiķina progress bar procentuālo vērtību
*/
function setProgressBar(){
	if (question <= nrOfQuestions){
		var percent = (question / nrOfQuestions) * 100;
		progress = document.getElementsByClassName("progress-bar")[0];
	 
		progress.style.width = percent +"%";
	}
	else{
		console.log('Progress bar Error');
	}
}
/*
setButtonText uzstāda pogu tekstu
*/
function setButtonText(str1, str2, str3, str4){
	var button1 = document.getElementById("answer1");
	var button2 = document.getElementById("answer2");
	var button3 = document.getElementById("answer3");
	var button4 = document.getElementById("answer4");

	button1.innerHTML = str1;
	button2.innerHTML = str2;
	button3.innerHTML = str3;
	button4.innerHTML = str4;
}
/*
setQuestionText uzstāda jautājuma tekstu 
*/
function setQuestionText(str){
	questionText = document.getElementById("question");
	questionText.innerHTML = str;
}
/*
addTpQuestionText pievieno tekstu jautājuma tekstam
*/
function addToQuestionText(str){
	questionText = document.getElementById("question");
	questionText.innerHTML = questionText.innerHTML + str;
}
/*
giveAnswer iegūst atbildi no nospiestās pogas
*/
function giveAnswer(x){
var answer = document.getElementById(x.id).innerHTML;
getNextQuestion(answer);

}
/*
calculateBackground apreiķina kāda būs balva - maksimālie punkti vislabākā balva, vidējs rezūltāts sliktāka balva, 0p nav balvas
*/

function calculateBackground(){
	var randomeNr = Math.floor(Math.random() * 3);
	if (question === correct) {
		switch(randomeNr){
			case 0:
				document.getElementById("content").style.backgroundImage = "url('Prices/coffeeBean.png')";
				addToQuestionText("<br/> Jūsu balva - kafija mēnesim!");
			break;
			case 1:
				document.getElementById("content").style.backgroundImage = "url('Prices/kfcPot.jpg')";
				addToQuestionText("<br/> Jūsu balva - spainis ar KFC vistiņu!");
			break;
			case 2:
				document.getElementById("content").style.backgroundImage = "url('Prices/cookie Pot.jpg')";
				addToQuestionText("<br/> Jūsu balva - cepumu spainis!");
			break;
		}
	}else if (correct !== 0) {
		switch(randomeNr){
			case 0:
				document.getElementById("content").style.backgroundImage = "url('Prices/cookie.jpg')";
				addToQuestionText("<br/> Jūsu balva - cepums!");
			break;
			case 1:
				document.getElementById("content").style.backgroundImage = "url('Prices/coke.jpeg')";
				addToQuestionText("<br/> Jūsu balva - kolas bundža!");
			break;
			case 2:
				document.getElementById("content").style.backgroundImage = "url('Prices/candies.jpg')";
				addToQuestionText("<br/> Jūsu balva - 5 konfektes!");
			break;
		}
	}else{
		
				document.getElementById("content").style.backgroundImage = "url('Prices/ssfile.png')";
				addToQuestionText("<br/> Jūsu balva - nekas! :/");
	}
	
}


/*
getNextQuestion funkcija iegūst nākošo jautājumu no datubāzes (php faila)

*/
function getNextQuestion(answer){
	
		try{
			 var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
      	var messageArray = this.responseText.split("|"); //Tiek sadalīta informācijas pakete
      	
      	if (question === 0) {//pirmā jautājuma infrmācijas apmaiņa ([0]uzzina cik daudz jautājumu ir testā)
      		nrOfQuestions = messageArray[0];
        	setQuestionText(messageArray[5]);
        	setButtonText(messageArray[1], messageArray[2], messageArray[3], messageArray[4]);
        	setProgressBar();
      		question ++;
      	}else if(question < nrOfQuestions){//parastās apmaiņas ([0]pagājušās atbildes rezūltāts, [5] kāds jautājums, [1-4] varianti)
	      	setQuestionText(messageArray[0]);
	        setQuestionText(messageArray[5]);
	        setButtonText(messageArray[1], messageArray[2], messageArray[3], messageArray[4]);
	        setProgressBar();
	        question ++;
	        correct = correct + parseInt(messageArray[0]);
    	}else{//pēdējā pakete satur tikai ([0] pagājušās atbildes rezūltātu)
    		setProgressBar();
    		correct = correct + parseInt(messageArray[0]);
    		setQuestionText("Apsveicu " + name +" ! <br/>" + correct + " no " + nrOfQuestions +" atbildēm ir pareizas!");
    		calculateBackground();
    		endPage();
    	}

      	}
    	};
    	xmlhttp.open("GET", "Tests/"+test +".php?question=" + question + "&answer=" + answer, true);
    	xmlhttp.send();
			
		}catch(e){
			alert( e.toString() );
		}
	
}